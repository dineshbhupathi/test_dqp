import React from "react";


export default function Footer() {
    return (

<footer className="footer ifix-footer">
  <div className="text-center p-3">
   @Copyright : Team Titans
  </div>
</footer>
    )
}